package com.sp.spminiproject2018;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.UUID;

public class NumFourActivity extends AppCompatActivity {

}

 /*1
public class NumFourActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numfour);


        final ProgressDialog pd = ProgressDialog.show(this, "", "Loading...",true);
        pd.setCancelable(true);

        WebView wvdev = (WebView) findViewById(R.id.webviewdev);
        wvdev.getSettings().setJavaScriptEnabled(true);
        wvdev.getSettings().setSupportZoom(true);
        wvdev.getSettings().setBuiltInZoomControls(true);
        wvdev.getSettings().setLoadsImagesAutomatically(true);
        wvdev.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        wvdev.loadUrl("http://192.168.2.10/");

        wvdev.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (pd != null && pd.isShowing()) {
                    pd.dismiss();
                }
            }
        });

     1*/


    /*
    //2S
    public class NumFourActivity extends AppCompatActivity implements View.OnClickListener {

        private static final String TAG = "BT_LEDOnOff"; //BT
        private static String logtag = "ET1544: ";//for use as the tag when logging

        String msg = "ET1544 : ";
        private Button btndevb1id,btndevb2id,btnOn,btnOff;

        //BT

        private static final String TAG = "LEDOnOff";

        private static final int REQUEST_ENABLE_BT = 1;
        private BluetoothAdapter btAdapter = null;
        private BluetoothSocket btSocket = null;
        private OutputStream outStream = null;

        // Well known SPP UUID
        private static final UUID MY_UUID =
                UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

        // Insert your server's MAC address
        private static String address = "00:00:00:00:00:00";

        //BT

        @Override
        protected void onCreate(Bundle savedInstanceState) {

            Log.d(TAG, "Inside onCreate()");//For BT

            StrictMode.ThreadPolicy policy = new StrictMode.
                    ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);

            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_numfour);

            btndevb1id = findViewById(R.id.btndevb1id);
            btndevb1id.setOnClickListener(this);

            btndevb2id = findViewById(R.id.btndevb2id);
            btndevb2id.setOnClickListener(this);

            /* commented off for BT
            //4start
            //http://digitalhacksblog.blogspot.com/2012/05/arduino-to-android-turning-led-on-and.html
            btnOn = findViewById(R.id.btnOn);
            btnOn.setOnClickListener(startListener); // Register the onClick listener with the implementation above

            btnOff = findViewById(R.id.btnOff);
            btnOff.setOnClickListener(stopListener); // Register the onClick listener with the implementation above
            //4end


            btAdapter = BluetoothAdapter.getDefaultAdapter();
            checkBTState();

            btnOn.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    sendData("1");
                    Toast msg = Toast.makeText(getBaseContext(),
                            "You have clicked On", Toast.LENGTH_SHORT);
                    msg.show();
                }
            });


            btnOff.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    sendData("0");
                    Toast msg = Toast.makeText(getBaseContext(),
                            "You have clicked Off", Toast.LENGTH_SHORT);
                    msg.show();
                }
            });



        }//OnCreate
        commented off for BT*/


        //excess
        //btnOn = (Button) findViewById(R.id.btnOn);
        //btnOff = (Button) findViewById(R.id.btnOff);

        

/* commented off for all


        public void commandArduino(String url){
            try {
                HttpClient httpclient = new DefaultHttpClient();
                httpclient.execute(new HttpGet(url));
            } catch (Exception e) {
            }
        }

        public void onClick(View v) {
            URL url = null;
            HttpURLConnection urlConnection = null;
            switch (v.getId())

            {
                case R.id.btndevb1id:
                    commandArduino("http://192.168.1.112/LED=ON");
                    break;
                case R.id.btndevb2id:
                    commandArduino("http://192.168.1.112/LED=OFF");
                    break;
                    //Toast.makeText(getApplicationContext(), "led_1on",Toast.LENGTH_SHORT).show();
                    /*
                    try {

                        //url = new URL("http://192.168.1.112/LED=1/");
                        //http://192.168.2.10/LED=0
                        //urlConnection = (HttpURLConnection) url.openConnection();
                        // urlConnection = (HttpURLConnection) url.openConnection();
                        //Log.d(msg, "Button ON is pressed");
                        //InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                        //  Log.d(msg, InputStream);


                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.d(msg, "URL Malformed");
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.d(msg, "IO exception");
                    } finally {
                        urlConnection.disconnect();
                        Log.d(msg, "Disconnected");
                    }
                */
          //  }


        //}

    //2E

    /* 3start
    //3start

        public void onClick(View v2) {
            URL url = null;
            HttpURLConnection urlConnection = null;
            switch (v2.getId())

            {
                case R.id.btndevb2id:

                    try {

                        url = new URL("http://192.168.2.10/LED=0");
                        //http://192.168.2.10/LED=0
                        urlConnection = (HttpURLConnection) url.openConnection();
                        // urlConnection = (HttpURLConnection) url.openConnection();
                        Log.d(msg, "Lichterkette1 pressed");
                        //InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                        //  Log.d(msg, InputStream);

                    } catch (MalformedURLException e) {
                        e.printStackTrace();
                        Log.d(msg, "URL Malformed");
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.d(msg, "IO exception");
                    } finally {
                        urlConnection.disconnect();
                        Log.d(msg, "Disconnected");
                    }

            }


        }



    //3end
    3end*/



     /* commented off For BT

    //4start
    //Button btnBT1 = (Button)findViewById(R.id.btnBT1);
    //btnBT1.setOnClickListener(startListener); // Register the onClick listener with the implementation above

    //Button btnBT2 = (Button)findViewById(R.id.btnBT2);
    //btnBT2.setOnClickListener(stopListener); // Register the onClick listener with the implementation above


        //Create an anonymous implementation of OnClickListener
        private View.OnClickListener startListener = new View.OnClickListener() {
            public void onClick(View v) {
                Log.d(logtag,"onClick() called - start button");
                Toast.makeText(NumFourActivity.this, "The Start button was clicked.", Toast.LENGTH_LONG).show();
                Log.d(logtag,"onClick() ended - start button");
            }
        };

        // Create an anonymous implementation of OnClickListener
        private View.OnClickListener stopListener = new View.OnClickListener() {
            public void onClick(View v) {
                Log.d(logtag,"onClick() called - stop button");
                Toast.makeText(NumFourActivity.this, "The Stop button was clicked.", Toast.LENGTH_LONG).show();
                Log.d(logtag,"onClick() ended - stop button");
            }
        };


        @Override
        protected void onStart() {//activity is started and visible to the user
            Log.d(logtag,"onStart() called");
            super.onStart();
        }
        @Override
        protected void onResume() {//activity was resumed and is visible again
            Log.d(logtag,"onResume() called");
            super.onResume();

        }
        @Override
        protected void onPause() { //device goes to sleep or another activity appears
            Log.d(logtag,"onPause() called");//another activity is currently running (or user has pressed Home)
            super.onPause();

        }
        @Override
        protected void onStop() { //the activity is not visible anymore
            Log.d(logtag,"onStop() called");
            super.onStop();

        }
        @Override
        protected void onDestroy() {//android has killed this activity
            Log.d(logtag,"onDestroy() called");
            super.onDestroy();
        }
    }

    //4end


    //BT

        protected void checkBTState() {
            // Check for Bluetooth support and then check to make sure it is turned on

            // Emulator doesn't support Bluetooth and will return null
            if (btAdapter == null) {
                errorExit("Fatal Error", "Bluetooth Not supported. Aborting.");
            } else {
                if (!btAdapter.isEnabled()) {
                    //Prompt user to turn on Bluetooth
                    Intent enableBtIntent = new Intent(btAdapter.ACTION_REQUEST_ENABLE);
                    startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
                } else Log.d(TAG, "...Bluetooth is enabled...");
            }
        }

        private void errorExit(String title, String message){
            Toast msg;
            msg = Toast.makeText(getBaseContext(),
                    title + " - " + message, Toast.LENGTH_SHORT);
            msg.show();
            finish();
        }

        private void sendData() {
            sendData();
        }

        private void sendData(String message) {
            byte[] msgBuffer;
            msgBuffer = message.getBytes();

            Log.d(TAG, "...Sending data: " + message + "...");

            try {
                outStream.write(msgBuffer);
            } catch (IOException e) {
                String msg = "In onResume() and an exception occurred during write: " + e.getMessage();
                if (address.equals("00:00:00:00:00:00"))
                    msg = msg + ".\n\nUpdate your server address from 00:00:00:00:00:00 to the correct address on line 37 in the java code";
                msg = msg +  ".\n\nCheck that the SPP UUID: " + MY_UUID.toString() + " exists on server.\n\n";

                errorExit("Fatal Error", msg);
            }
        }
    }

    //BT
    commented off BT */


//}
//NumFourActivity
//*******************************************************//



