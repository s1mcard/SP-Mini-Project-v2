package com.sp.spminiproject2018;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;

import java.net.HttpURLConnection;
import java.net.URL;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

//import static com.sp.spminiproject2018.R.id.RM1BtnON;

public class NumThreeActivity extends AppCompatActivity implements View.OnClickListener {

    private Button RM1BtnOFFid, RM1BtnONid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numthree);


        String username = getIntent().getStringExtra("username");
        String title = getIntent().getStringExtra("title");
        Toast.makeText(this, username, Toast.LENGTH_SHORT).show();

        TextView tview2 = (TextView) findViewById(R.id.txtusername2);
        tview2.setText("Username: " + username + "   " + title);

        final ProgressDialog pd = ProgressDialog.show(this, "", "Loading...", true);
        pd.setCancelable(true);

        WebView wv3 = (WebView) findViewById(R.id.webview3);
        wv3.getSettings().setJavaScriptEnabled(true);
        wv3.getSettings().setSupportZoom(true);
        wv3.getSettings().setBuiltInZoomControls(true);
        wv3.getSettings().setLoadsImagesAutomatically(true);
        wv3.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        //	60:01:94:52:8A:B0  	ESP_528AB0  WeMOS
        wv3.loadUrl("http://192.168.1.112");

        // btn
        StrictMode.ThreadPolicy policy = new StrictMode.
                ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        //super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_numthree);

        RM1BtnONid = findViewById(R.id.RM1BtnONid);
        RM1BtnONid.setOnClickListener(this);

        RM1BtnOFFid = findViewById(R.id.RM1BtnOFFid);
        RM1BtnOFFid.setOnClickListener(this);
        //btn

        wv3.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (pd != null && pd.isShowing()) {
                    pd.dismiss();
                }
            }
        });


        WebView wv4 = (WebView) findViewById(R.id.webview4);
        wv4.getSettings().setJavaScriptEnabled(true);
        wv4.getSettings().setSupportZoom(true);
        wv4.getSettings().setBuiltInZoomControls(true);
        wv4.getSettings().setLoadsImagesAutomatically(true);
        wv4.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        //F8:F0:05:F7:D7:35 MKR1000
        wv4.loadUrl("http://192.168.1.113");

        wv4.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (pd != null && pd.isShowing()) {
                    pd.dismiss();
                }
            }
        });


    }//OnCreate


    public void commandArduino(String url) {
        try {
            HttpClient httpclient = new DefaultHttpClient();
            httpclient.execute(new HttpGet(url));
        } catch (Exception e) {
        }
    }


    public void onClick(View v) {
        URL url = null;
        HttpURLConnection urlConnection = null;

        switch (v.getId())
        {
            case R.id.RM1BtnONid:
                commandArduino("http://192.168.1.112/LED=ON");
                break;
            case R.id.RM1BtnOFFid:
                commandArduino("http://192.168.1.112/LED=OFF");
                break;
            //Toast.makeText(getApplicationContext(), "led_1on",Toast.LENGTH_SHORT).show();
        }
    }
}
