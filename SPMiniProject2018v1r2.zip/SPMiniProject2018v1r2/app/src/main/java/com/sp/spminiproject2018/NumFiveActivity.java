package com.sp.spminiproject2018;


import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;



//public class NumFiveActivity {
//}



// http://googlerobotic.com/androidfetching-data-thingspeak-arduino/

//public abstract class NumFiveActivity extends AppCompatActivity {

public class NumFiveActivity extends AppCompatActivity {


    // private static final String THINGSPEAK_API_KEY = "THINGSPEAK READ API KEY"; //GARBAGE KEY
    // private static final String THINGSPEAK_API_KEY_STRING = "THINGSPEAK READ API KEY";

    //private static final String THINGSPEAK_API_KEY = "EXY2NHW14O1YCFHT"; //GARBAGE KEY
    //private static final String THINGSPEAK_API_KEY = "Q8PAGR4TM1055ARS"; //GARBAGE KEY


    //private static final String THINGSPEAK_API_KEY = "Q8PAGR4TM1055ARS"; //GARBAGE KEY

    //private static final String THINGSPEAK_CHANNEL_ID = "544972";

    //peter
    /*
    private static final String THINGSPEAK_CHANNEL_ID = "365111";
    private static final String TAG = "UsingThingspeakAPI";
    //WRITE: AP7XU84E0X1G3AHQ
    //READ: IITGGG64KSK0PPUS
    private static final String THINGSPEAK_API_KEY = "IITGGG64KSK0PPUS"; //GARBAGE KEY
    */
    //peter

    //mine
    private static final String THINGSPEAK_CHANNEL_ID = "544972";
    private static final String TAG = "UsingThingspeakAPI";
    //WRITE: MVAVR6ZA9OFRLLBB
    //READ:  EXY2NHW14O1YCFHT
    private static final String THINGSPEAK_API_KEY = "EXY2NHW14O1YCFHT"; //GARBAGE KEY

    //mine


    private static final String THINGSPEAK_API_KEY_STRING = "THINGSPEAK READ API KEY";

    /* Be sure to use the correct fields for your own app*/
    private static final String THINGSPEAK_FIELD1 = "Temperature";
    private static final String THINGSPEAK_FIELD2 = "Humidity";
    private static final String THINGSPEAK_UPDATE_URL = "https://api.thingspeak.com/update?";
    private static final String THINGSPEAK_CHANNEL_URL = "https://api.thingspeak.com/channels/";
    //private static final String THINGSPEAK_CHANNEL_URL = "184.106.153.149";
    private static final String THINGSPEAK_FEEDS_LAST = "/feeds/last?";

    TextView textView7,textView8;
    Button btnThingSpeak,btnThingView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numfive);


        textView7= findViewById(R.id.textView7);
        textView8= findViewById(R.id.textView8);
        btnThingSpeak= findViewById(R.id.btnThingSpeak);
        textView8.setText("");

        //btnThingView = findViewById(R.id.btnThingView);
        //btnThingView.setOnClickListener();


        btnThingSpeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    new FetchThingspeakTask().execute();
                }
                catch(Exception e){
                    Log.e("ERROR", e.getMessage(), e);
                }
            }
        });
    }
    class FetchThingspeakTask extends AsyncTask<Void, Void, String> {

        protected void onPreExecute() {
            textView8.setText("Fetching Data from Server....");
        }
        protected String doInBackground(Void... urls) {
            try {
                /*
                // commented off for URL - the original code

                URL url = new URL(THINGSPEAK_CHANNEL_URL + THINGSPEAK_CHANNEL_ID +
                        THINGSPEAK_FEEDS_LAST + THINGSPEAK_API_KEY_STRING + "=" +
                        THINGSPEAK_API_KEY + "");

                //commented off for URL
                */

                /*
                //url test 1 failed

                URL url = new URL(THINGSPEAK_CHANNEL_URL + THINGSPEAK_CHANNEL_ID +
                        THINGSPEAK_FEEDS_LAST + THINGSPEAK_API_KEY_STRING + "=" +
                        THINGSPEAK_API_KEY + "");


                //url test 1 failed
                */

                //url test 2 failed
                //URL url = new URL("GET" + "ttps://api.thingspeak.com/channels/544972" + "/feeds/last?" + "THINGSPEAK_API_KEY_STRING" + "=" + "Q8PAGR4TM1055ARS");
                //URL url = new URL("GET https://api.thingspeak.com/channels/544972/fields/1.json?results=2");

                //url test 3
                /*
                        URL url = new URL(THINGSPEAK_CHANNEL_URL + THINGSPEAK_CHANNEL_ID +
                        THINGSPEAK_FEEDS_LAST + THINGSPEAK_API_KEY_STRING + "=" +
                        THINGSPEAK_API_KEY + "");

                // THINGSPEAK_CHANNEL_URL + THINGSPEAK_CHANNEL_ID +  THINGSPEAK_FEEDS_LAST + THINGSPEAK_API_KEY_STRING=THINGSPEAK_API_KEY
                // https://api.thingspeak.com/channels/544972/feeds/last?api_key=EXY2NHW14O1YCFHT
                */
                //url test 3


                //url test 4
                //URL url = new url("https://184.106.153.149/channels/365111/feeds/last?THINGSPEAK_READ_API_KEY=IITGGG64KSK0PPUS");

                //url test 5
                // https://api.thingspeak.com/channels/365111/fields/1.json?api_key=IITGGG64KSK0PPUS&results=2
                //URL url = new url("https://api.thingspeak.com/channels/365111/fields/1.json?api_key=IITGGG64KSK0PPUS");
                //URL url = new URL("https://api.thingspeak.com/channels/365111/fields/1.json?api_key=IITGGG64KSK0PPUS");
                //URL url = new URL("https://api.thingspeak.com/channels/365111/feeds/last?THINGSPEAK_READ_API_KEY=IITGGG64KSK0PPUS\"\"");
                //URL url = new URL("https://api.thingspeak.com/channels/365111/fields/1.json?api_key=IITGGG64KSK0PPUS"); // no error but fetch no result
                //URL url = new URL("https://api.thingspeak.com/channels/365111/?api_key=IITGGG64KSK0PPUS"); //craashed
                //URL url = new URL("https://api.thingspeak.com/channels/365111/fields/?api_key=IITGGG64KSK0PPUS"); //compile ok, fetch error
                //URL url = new URL("https://api.thingspeak.com/channels/365111/feeds/last?api_key=IITGGG64KSK0PPUS\"\"");
                //URL url = new URL("https://api.thingspeak.com/channels/365111/feeds/last?THINGSPEAK READ API KEY=IITGGG64KSK0PPUS\"\"");
                //URL url = new URL("https://api.thingspeak.com/channels/365111/fields/1.json?api_key=AP7XU84E0X1G3AHQ&results=2\"\"");
                //URL url = new URL("https://api.thingspeak.com/channels/365111/feeds.json?api_key=IITGGG64KSK0PPUS&results=2\"\"");
                //URL url = new URL("https://api.thingspeak.com/channels/365111/feeds.json?api_key=IITGGG64KSK0PPUS&results=2\"\"");
                URL url = new URL("https://api.thingspeak.com/channels/544972/feeds/last?api_key=EXY2NHW14O1YCFHT");

                //For reference only - no updating here
                //Get a Channel Field
                //GET https://api.thingspeak.com/channels/544972/fields/1.json?results=2
                //Get a Channel Feed
                //GET https://api.thingspeak.com/channels/544972/feeds.json?results=2

                // Channel id 544972
                // Channel name ET1544
                // Read:  EXY2NHW14O1YCFHT
                // Write: MVAVR6ZA9OFRLLBB
                // acoount api Q8PAGR4TM1055ARS

                //private static final String THINGSPEAK_API_KEY = "EXY2NHW14O1YCFHT"; //GARBAGE KEY
                //private static final String THINGSPEAK_API_KEY_STRING = "EXY2NHW14O1YCFHT";
                //private static final String THINGSPEAK_FIELD1 = "Temperature";
                //private static final String THINGSPEAK_FIELD2 = "Humidity";
                //private static final String THINGSPEAK_UPDATE_URL = "https://api.thingspeak.com/update?";
                //private static final String THINGSPEAK_CHANNEL_URL = "https://api.thingspeak.com/channels/";
                //private static final String THINGSPEAK_FEEDS_LAST = "/feeds/last?";

                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                try {
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
                    StringBuilder stringBuilder = new StringBuilder();
                    String line;
                    while ((line = bufferedReader.readLine()) != null) {
                        stringBuilder.append(line).append("\n");
                    }
                    bufferedReader.close();
                    return stringBuilder.toString();
                }
                finally{
                    urlConnection.disconnect();
                }
            }
            catch(Exception e) {
                Log.e("ERROR", e.getMessage(), e);
                return null;
            }
        }


        protected void onPostExecute(String response) {
            if(response == null) {
                Toast.makeText(NumFiveActivity.this, "There was an error - response is null", Toast.LENGTH_SHORT).show();
                textView8.setText("There was an error - response is null");
                return;
            }


            try {
                JSONObject channel = (JSONObject) new JSONTokener(response).nextValue();
                double v1 = channel.getDouble(THINGSPEAK_FIELD1);
                if(v1>=10) {
                    textView7.setText("HI ALL  ");
                } else {
                    textView7.setText("NO VALUES");
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }



    /*
    //https://stackoverflow.com/questions/49188006/fetching-json-data-from-thingspeak-to-android-app

    public void fetchData(){
        String lightApi = "https://api.thingspeak.com/channels/444149/fields/1.json?api_key=EE90JXIIKAEFUT7S&results=2";
        JsonObjectRequest objectRequest =new JsonObjectRequest(DownloadManager.Request.Method.GET, lightApi, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray feeds = response.getJSONArray("feeds");
                            for(int i=0; i<feeds.length();i++){
                                JSONObject jo = feeds.getJSONObject(i);
                                String l=jo.getString("field1");
                                Toast.makeText(getApplicationContext(),l,Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

            }
        });
    }
//https://stackoverflow.com/questions/49188006/fetching-json-data-from-thingspeak-to-android-app
*/

    /*
    //20180812-1216
    //String packageName = "com.google.android.gm";
    //APP ID cinetica_tech.thingview (free version)
    //APP ID com.cinetica_tech.thingview.full (full version)

    //
    String packageName = "com.cinetica_tech.thingview";

    public void lauchThingView(Context context,String packageName) {
        Intent intent = context.getPackageManager().getLaunchIntentForPackage(packageName);
        //Intent intent = context.getPackageManager().getLaunchIntentForPackage("com.cinetica_tech.thingview");



        if (intent == null) {
            // Bring user to the market or let them choose an app?
            // com.cinetica_tech.thingview
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("market://details?id=" + packageName));
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        context.startActivity(intent);
        startActivity(intent);
    }

    //20180812-1216
    */

    //
    //Intent intent = new Intent(Intent.ACTION_MAIN);
    //intent.setComponent(new ComponentName("com.package.address","com.package.address.MainActivity"));
    //startActivity(intent);
    //


    // in onCreate method
    //String appName = "Gmail";
    //String packageName = "com.google.android.gm";


   // String appName = "ThingView";
    //String packageName = "com.cinetica_tech.thingview";

    /*
    //openApp(context, appName, packageName);
    //copied to oncreate
    public static void openApp(Context context, String appName, String packageName) {
        if (isAppInstalled(context, packageName))
            if (isAppEnabled(context, packageName))
                context.startActivity(context.getPackageManager().getLaunchIntentForPackage(packageName));
            else Toast.makeText(context, appName + " app is not enabled.", Toast.LENGTH_SHORT).show();
        else Toast.makeText(context, appName + " app is not installed.", Toast.LENGTH_SHORT).show();
    }

    private static boolean isAppInstalled(Context context, String packageName) {
        PackageManager pm = context.getPackageManager();
        try {
            pm.getPackageInfo(packageName, PackageManager.GET_ACTIVITIES);
            return true;
        } catch (PackageManager.NameNotFoundException ignored) {
        }
        return false;
    }

    private static boolean isAppEnabled(Context context, String packageName) {
        boolean appStatus = false;
        try {
            ApplicationInfo ai = context.getPackageManager().getApplicationInfo(packageName, 0);
            if (ai != null) {
                appStatus = ai.enabled;
            }
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        return appStatus;
    }
    */


    /*
    //20180812-1219A - tested ok

    public void gotoThingViewFunction (View v){

        Uri webpage = Uri.parse("http://www.android.com");
        Intent webIntent = new Intent(Intent.ACTION_VIEW, webpage);

        //Intent intent = new Intent(this, NumFiveActivity.class);
        startActivity(webIntent);
    }
    //20180812-1219B
    */


    //20180812-1300A
    // only works if app has a launcher activity
    //String packageName = "com.cinetica_tech.thingview";

    public void gotoThingViewFunction (View v) {

        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.cinetica_tech.thingview");
        startActivity(launchIntent);

        // works if we know the name of the main activity, even if not a launcher
        //Intent intent = new Intent(Intent.ACTION_MAIN);
        //intent.setClassName("com.example.yourapp", "com.example.yourapp.MainActivity");
        //startActivity(intent);

    }
    //20180812-1300B


} //NumFiveActivity



