package com.sp.spminiproject2018;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private String adminusername = "ET1544Admin";
    private String adminpassword = "password";

    private String username = "ET1544User";
    private String userpassword = "password";

    private String AdminMode = "Admin Mode";
    private String UserMode = "User Mode";

    private EditText txtusername, txtpassword;
    private CheckBox cbAdminMode, cbUserMode;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtusername = (EditText) findViewById(R.id.txtusername);
        txtpassword = (EditText) findViewById(R.id.txtpassword);

        cbAdminMode = (CheckBox) findViewById(R.id.checkBoxAdminMode);
        cbUserMode = (CheckBox) findViewById(R.id.checkBoxUserMode);

        cbAdminMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cbAdminMode.isChecked())
                {
                    cbUserMode.setChecked(false);
                    Toast.makeText(MainActivity.this,"Admin Mode Box is checked",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Admin Mod Box is not checked",Toast.LENGTH_LONG).show();
                }

            }
        });

        cbUserMode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(cbUserMode.isChecked())
                {
                    cbAdminMode.setChecked(false);
                    Toast.makeText(MainActivity.this,"User Mode Box is checked",Toast.LENGTH_LONG).show();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"User Mod Box is not checked",Toast.LENGTH_LONG).show();
                }

            }
        });

    }
    //OnCreate



/*1
    public void gotologinfunction (View v) {
        if (!(cbAdminMode.isChecked() || cbUserMode.isChecked())){
            Toast.makeText(this, "Please tick checkbox", Toast.LENGTH_SHORT).show();}
        else {
            if (txtusername.getText().toString().equals("") || txtpassword.getText().toString().equals("")) {
                Toast.makeText(this, "Please enter username or password", Toast.LENGTH_SHORT).show();
            } else {

                if (txtusername.getText().toString().equals(username) && txtpassword.getText().toString().equals(password)) {
                    Intent intent = new Intent(this, NumTwoActivity.class);
                    intent.putExtra("username", username);
                    if (cbAdminMode.isChecked()) intent.putExtra("title", AdminMode);
                    else intent.putExtra("title",UserMode);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Username or Password is incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        }


    }
1*/

/*2
    public void gotologinfunction (View v) {
        if (cbUserMode.isChecked()){
            //cbUserMode.setChecked(false);
            Toast.makeText(this, "Please tick checkbox", Toast.LENGTH_SHORT).show();
        }
        else {
            if (txtusername.getText().toString().equals("") || txtpassword.getText().toString().equals("")) {
                Toast.makeText(this, "Please enter username or password", Toast.LENGTH_SHORT).show();
            } else {

                if (txtusername.getText().toString().equals(username) && txtpassword.getText().toString().equals(password)) {
                    Intent intent = new Intent(this, NumTwoActivity.class);
                    intent.putExtra("username", username);
                    if (cbAdminMode.isChecked()) intent.putExtra("title", AdminMode);
                    else intent.putExtra("title",UserMode);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Username or Password is incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        }


    }
2*/


    public void gotologinfunction (View v) {
        if (cbUserMode.isChecked()){
            //cbUserMode.setChecked(false);
            Toast.makeText(this, "User Mode Checkbox is ticked", Toast.LENGTH_SHORT).show();



            Intent intent = new Intent(this, NumThreeActivity.class);
            intent.putExtra("username", username);


            /*
            if (cbAdminMode.isChecked()) intent.putExtra("title", AdminMode);
            else intent.putExtra("title",UserMode);
            startActivity(intent);
            */
            intent.putExtra("title", UserMode);
            startActivity(intent);

        }
        else {

            if(cbAdminMode.isChecked()){
                Toast.makeText(this, "Admin Mode Checkbox is checked", Toast.LENGTH_SHORT).show();
            }


            if (txtusername.getText().toString().equals("") || txtpassword.getText().toString().equals("")) {
                Toast.makeText(this, "Please enter username or password", Toast.LENGTH_SHORT).show();
            } else {

                if (txtusername.getText().toString().equals(adminusername) && txtpassword.getText().toString().equals(adminpassword)) {
                    Intent intent = new Intent(this, NumTwoActivity.class);
                    intent.putExtra("username", adminusername);
                    if (cbAdminMode.isChecked()) intent.putExtra("title", AdminMode);
                    else intent.putExtra("title",UserMode);
                    startActivity(intent);
                } else {
                    Toast.makeText(this, "Username or Password is incorrect", Toast.LENGTH_SHORT).show();
                }
            }
        }


    }


    public void gotoclearfunction (View v) {
        txtusername.setText("");
        txtpassword.setText("");
    }//ClearButton



    public void gotoexitfunction (View v) {
        finish();
    }//ExitButton


}//MainActivity
