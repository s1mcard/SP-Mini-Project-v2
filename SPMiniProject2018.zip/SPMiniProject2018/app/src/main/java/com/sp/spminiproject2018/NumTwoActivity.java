package com.sp.spminiproject2018;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import android.widget.Toast;

public class NumTwoActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_numtwo);

        String username = getIntent().getStringExtra("username");
        String title = getIntent().getStringExtra("title");
        Toast.makeText(this, username, Toast.LENGTH_SHORT).show();

        TextView tview = (TextView) findViewById(R.id.txtusername);
        tview.setText("Username: " + username + "   " + title);

        final ProgressDialog pd = ProgressDialog.show(this, "", "Loading...",true);
        pd.setCancelable(true);

        WebView wv = (WebView) findViewById(R.id.webview);
        wv.getSettings().setJavaScriptEnabled(true);
        wv.getSettings().setSupportZoom(true);
        wv.getSettings().setBuiltInZoomControls(true);
        wv.getSettings().setLoadsImagesAutomatically(true);
        wv.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        //	60:01:94:52:8A:B0  	ESP_528AB0
        wv.loadUrl("http://192.168.1.1/indexf.asp");



        wv.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (pd != null && pd.isShowing()) {
                    pd.dismiss();
                }
            }
        });


        WebView wv2 = (WebView) findViewById(R.id.webview2);
        wv2.getSettings().setJavaScriptEnabled(true);
        wv2.getSettings().setSupportZoom(true);
        wv2.getSettings().setBuiltInZoomControls(true);
        wv2.getSettings().setLoadsImagesAutomatically(true);
        wv2.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
        //F8:F0:05:F7:D7:35
        wv2.loadUrl("http://192.168.1.114/phpmyadmin/server_databases.php");

        wv2.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                if (pd != null && pd.isShowing()) {
                    pd.dismiss();
                }
            }
        });
    }
}